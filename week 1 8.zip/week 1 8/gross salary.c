#include <stdio.h>

int main() {
    float BP, TA, DA, GS;

    printf("Enter Basic Pay (BP): ");
    scanf("%f", &BP);

    TA = 0.10 * BP;
    DA = 0.15 * BP;

    GS = BP + TA + DA;

    printf("Gross Salary = %f\n", GS);

    return 0;
}
