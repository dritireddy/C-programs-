#include<math.h>
int main()
{
	double n,x;
	scanf("%f",&n);
	x= pow(2,n);
	printf("power=%f",x);
	return 0;
}
