#include <stdio.h>

int main() {
    double radius, area;

    printf("Enter the radius of the circle: ");
    scanf("%lf", &radius);

    area = 3.14 * radius * radius;

    printf("Area of the circle = %.2lf\n", area);

    return 0;
}
