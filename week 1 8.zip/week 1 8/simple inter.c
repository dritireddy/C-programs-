#include <stdio.h>

int main() {
    float p, t, r, I;

    printf("Enter value of P, T, R: ");
    scanf("%f %f %f", &p, &t, &r);

    I = (p * t * r) / 100;

    printf("Interest = %f\n", I);

    return 0;
}
