#include<stdio.h>
int main()
{
	int a,b,avg;
	printf("enter a and b values");
	scanf("%d%d",&a,&b);
	avg=(a+b)/2;
	printf("avg=%d",avg);
	return 0;
}
