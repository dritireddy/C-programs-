#include<stdio.h>
int main()
{
	int x,n,i,sum=0,rem,fact;
	printf("enter n value\n");
	scanf("%d",&n);
	x=n;
	while(n!=0)
	{
		rem=n%10;
	    for(i=1,fact=1;i<=rem;i++)
	    {
	    	fact=fact*i;
		}
		sum=sum+fact;
		n=n/10;
	}
	if (x==sum)
	printf("strong no.");
	else printf("not strong no.");
	return 0;
}
