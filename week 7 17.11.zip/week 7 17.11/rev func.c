include <stdio.h>

int rev(int n)
{
    int sum = 0, rem;
    while (n > 0)
    {
        rem = n % 10;
        sum = (sum * 10) + rem;
        n = n / 10;
    }
    return sum;
}

int main()
{
    int n;
    printf("Enter a number:\n");
    scanf("%d", &n);

    printf("Reverse = %d\n", rev(n));

    return 0;
}

