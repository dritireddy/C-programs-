#include <stdio.h>

int main()
{
    int n, i;

    printf("Enter number of elements:\n");
    scanf("%d", &n);

    int a[n];

    printf("Enter the elements:\n");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    int max = a[0];

    for (i = 1; i < n; i++)
    {
        if (a[i] > max)
            max = a[i];
    }

    printf("Maximum element = %d", max);

    return 0;
}
