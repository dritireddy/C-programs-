#include <stdio.h>

int main() {
    int sub[100], n, i, sum = 0;

    printf("Enter number of subjects:\n");
    scanf("%d", &n);

    printf("Enter marks:\n");
    for (i = 0; i < n; i++) {
        scanf("%d", &sub[i]);
    }

    for (i = 0; i < n; i++) {
        sum = sum + sub[i];
    }

    printf("Sum = %d", sum);

    return 0;
}
