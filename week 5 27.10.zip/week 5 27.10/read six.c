#include <stdio.h>

int main() {
    int a[6], i;

    printf("Enter 6 subject marks:\n");

    for (i = 0; i < 6; i++) {
        scanf("%d", &a[i]);
    }

    printf("You entered:\n");
    for (i = 0; i < 6; i++) {
        printf("%d ", a[i]);
    }

    return 0;
}
