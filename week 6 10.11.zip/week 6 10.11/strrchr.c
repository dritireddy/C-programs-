#include <stdio.h>
#include <string.h>

int main()
{
    char s[50], ch;
    char *p;

    gets(s);
    scanf("%c", &ch);

    p = strchr(s, ch);

    if(p)
        printf("Found");
    else
        printf("Not Found");

    return 0;
}
