#include <stdio.h>
#include <string.h>

int main()
{
    char s[50];
    int len;

    gets(s);

    len = strlen(s);

    printf("%d", len);

    return 0;
}
