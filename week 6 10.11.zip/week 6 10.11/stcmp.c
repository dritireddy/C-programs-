#include <stdio.h>
#include <string.h>

int main()
{
    char a[50], b[50];
    int r;

    gets(a);
    gets(b);

    r = strcmp(a, b);

    if(r == 0)
        printf("Equal");
    else
        printf("Not Equal");

    return 0;
}
