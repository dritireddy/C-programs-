#include<stdio.h>
int main()
{
    FILE *fp1, *fp2;
    char ch[10];
    int i,j;
    fp1 = fopen("input.txt", "r");
    fp2 = fopen("reverse.txt", "w");
    if(fp1 == NULL || fp2 == NULL)
    {
        printf("Error");
        exit(0);
    }
    while((ch[i]=fgetc(fp1))!=EOF)
        i++;
    for(j=i-1;j>=0;j--)
        fputc(ch[j], fp2);
    fclose(fp1);
    fclose(fp2);
    return 0;
}
