#include <stdio.h>
enum days { sunday, monday, tuesday, wednesday, thursday, friday, saturday };
int main()
{
    enum days today;
    today = friday;
    printf("day=%d\n", today);
    return 0;
}
