#include <stdio.h>
#include <stdlib.h>
int main()
{
    FILE *fp1, *fp2;
    int n, sum=0, temp, rem;
    fp1 = fopen("input.txt", "r");
    fp2 = fopen("output.txt", "w");
    if(fp1 == NULL || fp2 == NULL)
    {
        printf("Error opening file\n");
        exit(0);
    }
    fscanf(fp1, "%d", &n);
    temp = n;
    while(n>0)
    {
        rem=n%10;
        sum=(sum*10)+rem;
        n=n/10;
    } 
    if(temp==sum)
        fprintf(fp2, "Palindrome number");
    else
        fprintf(fp2, "Not a palindrome number");
    fclose(fp1);
    fclose(fp2);
    return 0;
}

