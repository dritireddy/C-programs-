#include <stdio.h>
#include<stdlib.h>
int main()
{
    FILE *f1, *f2, *f3;
    char ch;
    f1 = fopen("input.txt", "r");
    f2 = fopen("output.txt", "r");
    f3 = fopen("merged.txt", "w");
    if(f1 == NULL || f2 == NULL || f3 == NULL)
    {
        printf("Error opening file\n");
        exit (0);
    }
        do
        {
            ch = fgetc(f1);
            if(ch != EOF)
                fputc(ch, f3);
        } while(ch != EOF);
 
        do
        {
            ch = fgetc(f2);
            if(ch != EOF)
                fputc(ch, f3);
        } while(ch != EOF);
    fclose(f1);
    fclose(f2);
    fclose(f3);

    return 0;
}

