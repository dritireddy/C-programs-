#include <stdio.h>

int main()
{
    int n,i,a[100];
    int *p;
    p = a;
    printf("Enter number");
    scanf("%d", &n);
    printf("Enter array values\n");
    for (i = 0; i<n; i++)
        scanf("%d",(p+i));
    printf("The values are\n");
    for (i = 0; i < n; i++)
        printf("%d ",*(p+i));
    return 0;
}
