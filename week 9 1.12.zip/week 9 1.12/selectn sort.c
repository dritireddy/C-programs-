#include <stdio.h>
void selection(int *x, int n);
int main()
{
    int n,i;
    int *p;
    printf("Enter size\n");
    scanf("%d", &n);
    int a[n];
    p = a;
    printf("Enter elements\n");
    for (i=0; i<n; i++)
        scanf("%d", (p + i));
    selection(p,n);
    printf("Sorted array:\n");
    for (i=0; i<n; i++)
        printf("%d ", *(p + i));
    return 0;
}
void selection(int *x, int n)
{
    int i,j,min,temp;
    for (i=0; i<n-1;i++)
    {
        min=i;
        for (j=i+1;j<n;j++)
        {
            if (*(x + j) < *(x + min))
                min = j;
        }
        if (i != min)
        {
            temp = *(x + i);
            *(x+i)= *(x + min);
            *(x+min)=temp;
        }
    }
}
