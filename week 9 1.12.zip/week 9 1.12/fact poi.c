#include <stdio.h>
int main()
{
    int i, n, fact = 1;
    int *p, *q;
    p = &n;
    q = &fact;
    printf("Enter number: ");
    scanf("%d", p);
    for (i=1;i<=n;i++)
    {
        *q=(*q)*i;
    }
    printf("fact=%d", *q);
    return 0;
}
