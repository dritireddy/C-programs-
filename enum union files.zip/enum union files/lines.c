#include <stdio.h>
#include <stdlib.h>
int main()
{
    FILE *fp;
    char ch;
    int lines = 0, words = 0, chars = 0;
    fp = fopen("input.txt", "r");
    if(fp == NULL)
    {
        printf("error");
        exit(0);
    }
    while((ch = fgetc(fp)) != EOF)
    {
        chars++;
        if(ch == '\n')
            lines++;
        if(ch == ' ' || ch == '\n' || ch == '\t')
            words++;
    }
    printf("Lines = %d\n", lines);
    printf("Words = %d\n", words);
    printf("Characters = %d\n", chars);
    fclose(fp);
    
    return 0;
}
