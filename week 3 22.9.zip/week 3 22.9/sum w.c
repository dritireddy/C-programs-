#include<stdio.h>
int main()
{
    int i=1;
    int sum=0;
    int n;
    printf("enter n");
    scanf("%d",&n);
    while(i<=n)
    {
        sum=sum+i;
        i++;
    }
    printf("%d",sum);
    return 0;
}