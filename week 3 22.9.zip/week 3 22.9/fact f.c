#include<stdio.h>
int main()
{
    int n;
    int fact=1;
    printf("enter n");
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
       fact=fact*i;
      
    }
     printf("fact=%d",fact);
    return 0;

}