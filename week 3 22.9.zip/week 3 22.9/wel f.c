#include<stdio.h>
int main()
{
    
    for(int i=1;i<=5;i++)
    {
        printf("welcome \n");

    }
    return 0;

}