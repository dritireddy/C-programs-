#include<stdio.h>
int main()
{
    int i=1;
    int n;
    printf("enter n ");
    scanf("%d",&n);
    while(i<=n)
    {
        printf("%d",i);
        i++;
    }
    return 0;
}