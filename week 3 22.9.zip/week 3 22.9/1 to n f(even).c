#include<stdio.h>
int main()
{
    int n;
    printf("enter n");
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        if(1%2==0)
        {
            printf("%d",i);
        }

    }
    return 0;

}