#include <stdio.h>
struct student
{
    char name[30];
    int roll;
    int marks[6];
    float percent;
};
int main()
{

    struct student s[3];
    int i,j,sum;
    for(i = 0; i < 3; i++)
    {
        sum=0;
        printf("enter details of student %d\n", i + 1);
        printf("enter name");
        scanf("%s", s[i].name);
        printf("enter roll no");
        scanf("%d", &s[i].roll);
        printf("enter 6 subject marks\n");
        for(j = 0; j < 6; j++)
        {
            scanf("%d", &s[i].marks[j]);
            sum = sum + s[i].marks[j];
        }
        s[i].percent =((sum / 600) * 100);
    
    }
        printf("student details\n");
        printf("name\t roll\t percentage\n");
        for(i = 0; i < 3; i++)
        {
        printf("%s\t %d\t %f\n", s[i].name, s[i].roll, s[i].percent);
        }
	    return 0;
}
