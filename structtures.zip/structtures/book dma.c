#include <stdio.h>
#include <stdlib.h>

struct book
{
    char name[30];
    char author[30];
    int pages;
    float price;
};

int main() 
{
    struct book *p;
    p = (struct book *) malloc(sizeof(struct book));
    if(p == NULL) 
    {
        printf("error");
        exit(0);
    }
    printf("enter book name");
    scanf("%s", p->name);
    printf("enter author");
    scanf("%s", p->author);
    printf("enter pages");
    scanf("%d", &p->pages);
    printf("enter price");
    scanf("%f", &p->price);
    printf("name = %s\n", p->name);
    printf("author = %s\n", p->author);
    printf("pages = %d\n", p->pages);
    printf("price = %f\n", p->price);
    free(p);
    return 0;
}
