#include <stdio.h>
struct complex
{
    int real;
    int img;
};
struct complex add( struct complex a, struct complex b)
{
    struct complex c;
    c.real = a.real + b.real;
    c.img = a.img + b.img;
    return c;
}

int main()
{
    struct complex c1, c2, c3;
    FILE *fp1, *fp2;
    fp1 = fopen("input.txt", "r");
    fp2 = fopen("output.txt", "w");
    if(fp1 == NULL || fp2 == NULL)
    {
        printf("error");
        return 0;
    }
    fscanf(fp1, "%d%d", &c1.real, &c1.img);
    fscanf(fp1, "%d%d", &c2.real, &c2.img);
    c3 = add(c1, c2);
    printf("sum = %d + %di\n", c3.real, c3.img);
    fprintf(fp2, "sum = %d + %di", c3.real, c3.img);
    fclose(fp1);
    fclose(fp2);
    return 0;
}
