#include <stdio.h>
struct employee
{
    int id;
    char name[30];
    float salary;
};
int main() 
{
    struct employee p[3];
    int i;
    for(i = 0; i < 3; i++) 
    {
        printf("enter details of employee %d\n", i + 1);
        printf("enter id");
        scanf("%d", &p[i].id);
        printf("enter name");
        scanf("%s", p[i].name);
        printf("enter salary");
        scanf("%f", &p[i].salary);
    }
    printf("employee details\n");
    for(i = 0; i < 3; i++) 
    {
        printf("employee %d\n", i + 1);
        printf("id=%d\n", p[i].id);
        printf("name=%s\n", p[i].name);
        printf("salary=%f\n", p[i].salary);
    }
    return 0;
}
