#include <stdio.h>
struct address
{
    int hno;
    char city[20];
    int pin;
};
struct student
{
    char name[30];
    int roll;
    int marks[6];
    struct address a;
};
int main()
{
    struct student s;
    int i;
    printf("Enter name");
    scanf("%s", s.name);
    printf("Enter roll no");
    scanf("%d", &s.roll);
    printf("Enter 6 subject marks\n");
    for(i = 0; i < 6; i++)
    {
        scanf("%d", &s.marks[i]);
    }
    printf("Enter house no");
    scanf("%d", &s.a.hno);
    printf("Enter city");
    scanf("%s", s.a.city);
    printf("Enter pin");
    scanf("%d", &s.a.pin);
    printf("Student details\n");
    printf("Name=%s\n", s.name);
    printf("Roll no=%d\n", s.roll);
    printf("Marks=\n");
    for(i = 0; i < 6; i++)
    {
        printf("%d ", s.marks[i]);
    }
    printf("House no=%d\n", s.a.hno);
    printf("City=%s\n", s.a.city);
    printf("Pin=%d\n", s.a.pin);
    return 0;
}
