#include <stdio.h>
union student
{
    int roll;
    float marks;
};
int main()
{
    union student s;
    s.roll = 101;
    printf("Student Roll: %d\n", s.roll);
    s.marks = 99.99;
    printf("Student Marks: %f\n", s.marks);
    return 0;
}

